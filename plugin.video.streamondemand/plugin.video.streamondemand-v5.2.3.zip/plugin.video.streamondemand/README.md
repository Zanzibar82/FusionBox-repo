![alt tag](https://raw.githubusercontent.com/Zanzibar82/plugin.video.streamondemand/master/icon.png)
# Stream On Demand

Italian son of pelisalacarta v4.0.3,
and only with Italian channels:
STREAM ON DEMAND
Fixed all new options with Italian channels,
translated the tweaked "buscador general" in Italian.
The downloadable .zip can be installed directly into Kodi.
It is suggested to remove any other pelisalacarta version first, restart Kodi and then install this.
Removed channels not in italian (sorry but that also makes the plugin lighter)
Removed adult options and contents for 2 reasons:

1) I have nephews age 3-16 and I don't want them to display by accident
adult contents on their parent's devices. I'll think about putting them back
if we find a password-entry solution.

2) there are TONS of ways to get to adult contents, even with Kodi.

Please note that for migrating the job from 3.9 to 4.0.3 I helped myself
with dentaku65's good work at start, but basically started back from skratch.

Also refer to forum: http://www.mimediacenter.info/foro/viewforum.php?f=36

THIS VERSION HAS AUTO-UPDATES TO THIS REPO.
JUST ENABLE UPDATES OPTIONS IN ADD-ON CONFIGURATION!

Special thanks to forum users:
Jesus (for pelisalacarta)
robalo (for being a master and a skilled a developer)
dentaku65 (for being a vulcano of ideas and a hard worker, and supporting moving the project here)
DrZ3r0 (for being an Italian skilled developer, author of many important servers' files)
Raùl (for his native general search)
Chryses (for ideas about auto-updates)
fenice82 (for editing the useful xml files for channels and for
          adapting pelisalacarta-UI to Streamondemand-PureIta, https://github.com/Fenice82/plugin.video.streamondemand-pureita)

WISHLIST: http://www.mimediacenter.info/foro/viewtopic.php?f=36&t=7022&p=26728#p26728
