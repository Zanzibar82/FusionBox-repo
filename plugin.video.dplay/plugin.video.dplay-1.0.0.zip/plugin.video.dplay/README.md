plugin.video.dplay
=================

Kodi unofficial plugin for Dplay (tested on Kodi 15.2 Isengard).
